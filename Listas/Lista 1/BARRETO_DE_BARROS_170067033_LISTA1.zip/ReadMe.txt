

Lista 1 - Pastas dos Projetos de cada Exercicio

* Exercicio 1
	ex1
* Exercicio 2
	ex2
* Exercicio 3
	ex3
* Exercicio 4
	ex4
* Exercicio 5
	ex5
* Exercicio 6
	ex6_barrelshift_multifuncional
* Exercicio 7
	ex7_somadores
	